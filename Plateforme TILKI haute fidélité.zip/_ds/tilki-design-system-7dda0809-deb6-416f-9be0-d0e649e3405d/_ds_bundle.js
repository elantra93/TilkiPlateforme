/* @ds-bundle: {"format":3,"namespace":"TILKIDesignSystem_7dda08","components":[{"name":"Icon","sourcePath":"components/core/Icon.jsx"},{"name":"Avatar","sourcePath":"components/display/Avatar.jsx"},{"name":"Badge","sourcePath":"components/display/Badge.jsx"},{"name":"Card","sourcePath":"components/display/Card.jsx"},{"name":"StatCard","sourcePath":"components/display/StatCard.jsx"},{"name":"Dialog","sourcePath":"components/feedback/Dialog.jsx"},{"name":"Tooltip","sourcePath":"components/feedback/Tooltip.jsx"},{"name":"Button","sourcePath":"components/forms/Button.jsx"},{"name":"Checkbox","sourcePath":"components/forms/Checkbox.jsx"},{"name":"Input","sourcePath":"components/forms/Input.jsx"},{"name":"Select","sourcePath":"components/forms/Select.jsx"},{"name":"Switch","sourcePath":"components/forms/Switch.jsx"},{"name":"Tabs","sourcePath":"components/navigation/Tabs.jsx"}],"sourceHashes":{"components/core/Icon.jsx":"3e71d33422f1","components/display/Avatar.jsx":"ff5bca976442","components/display/Badge.jsx":"292d8f920990","components/display/Card.jsx":"d604b8d456fe","components/display/StatCard.jsx":"27d9d75d51e7","components/feedback/Dialog.jsx":"53ce74000fa8","components/feedback/Tooltip.jsx":"a12889d80d42","components/forms/Button.jsx":"391d9e8e9c87","components/forms/Checkbox.jsx":"ad9453d5f122","components/forms/Input.jsx":"6f123ad5238e","components/forms/Select.jsx":"ed641695ff6e","components/forms/Switch.jsx":"1e0f744244a7","components/navigation/Tabs.jsx":"f2e59d5758d2","ui_kits/tilki-app/AppShell.jsx":"8dc65bcc76bd","ui_kits/tilki-app/Dashboard.jsx":"fde1436c3383","ui_kits/tilki-app/PolicyDetail.jsx":"1f8ce75b1289","ui_kits/tilki-app/QuoteFlow.jsx":"52d27a828eb9","ui_kits/tilki-app/SignIn.jsx":"5f34db3a29a9","ui_kits/tilki-app/data.js":"e9d59d7feece"},"inlinedExternals":[],"unexposedExports":[]} */

(() => {

const __ds_ns = (window.TILKIDesignSystem_7dda08 = window.TILKIDesignSystem_7dda08 || {});

const __ds_scope = {};

(__ds_ns.__errors = __ds_ns.__errors || []);

// components/core/Icon.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
/**
 * TILKI Icon — thin-stroke line icons from the Lucide set.
 * Requires the Lucide UMD script to be present (window.lucide).
 * Names are kebab-case Lucide ids, e.g. "shield", "umbrella", "file-text".
 */
function toPascal(name) {
  return String(name).split(/[-_]/).map(s => s.charAt(0).toUpperCase() + s.slice(1)).join('');
}
function Icon({
  name,
  size = 20,
  strokeWidth = 2,
  color = 'currentColor',
  style = {},
  ...rest
}) {
  const lib = typeof window !== 'undefined' && window.lucide && window.lucide.icons || {};
  const node = lib[toPascal(name)] || lib[name];
  if (!node) {
    return /*#__PURE__*/React.createElement("svg", {
      width: size,
      height: size,
      viewBox: "0 0 24 24",
      style: style,
      "aria-hidden": "true"
    });
  }
  return /*#__PURE__*/React.createElement("svg", _extends({
    width: size,
    height: size,
    viewBox: "0 0 24 24",
    fill: "none",
    stroke: color,
    strokeWidth: strokeWidth,
    strokeLinecap: "round",
    strokeLinejoin: "round",
    style: {
      display: 'block',
      flexShrink: 0,
      ...style
    },
    "aria-hidden": "true"
  }, rest), node.map((child, i) => {
    const tag = child[0];
    const attrs = child[1] || {};
    return React.createElement(tag, {
      key: i,
      ...attrs
    });
  }));
}
Object.assign(__ds_scope, { Icon });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/core/Icon.jsx", error: String((e && e.message) || e) }); }

// components/display/Avatar.jsx
try { (() => {
/**
 * TILKI Avatar — circular initials or image. Brand-tinted by default.
 */
function Avatar({
  name = '',
  src,
  size = 'md',
  style = {}
}) {
  const sizes = {
    sm: 32,
    md: 40,
    lg: 56,
    xl: 72
  };
  const px = sizes[size] || sizes.md;
  const initials = name.split(/\s+/).filter(Boolean).slice(0, 2).map(w => w[0]).join('').toUpperCase();
  return /*#__PURE__*/React.createElement("div", {
    style: {
      width: px,
      height: px,
      borderRadius: '50%',
      flexShrink: 0,
      background: src ? 'var(--bg-sunken)' : 'var(--brand-subtle)',
      color: 'var(--blue-700)',
      display: 'inline-flex',
      alignItems: 'center',
      justifyContent: 'center',
      overflow: 'hidden',
      fontWeight: 'var(--weight-semibold)',
      fontSize: px * 0.4,
      letterSpacing: 0,
      userSelect: 'none',
      ...style
    }
  }, src ? /*#__PURE__*/React.createElement("img", {
    src: src,
    alt: name,
    style: {
      width: '100%',
      height: '100%',
      objectFit: 'cover'
    }
  }) : initials);
}
Object.assign(__ds_scope, { Avatar });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/display/Avatar.jsx", error: String((e && e.message) || e) }); }

// components/display/Badge.jsx
try { (() => {
/**
 * TILKI Badge — small status pill. Subtle tinted background by tone.
 */
function Badge({
  tone = 'neutral',
  dot = false,
  children,
  style = {}
}) {
  const tones = {
    neutral: {
      bg: 'var(--bg-sunken)',
      fg: 'var(--text-secondary)',
      dotc: 'var(--neutral-500)'
    },
    brand: {
      bg: 'var(--brand-subtle)',
      fg: 'var(--blue-700)',
      dotc: 'var(--brand)'
    },
    success: {
      bg: 'var(--success-subtle)',
      fg: 'var(--green-600)',
      dotc: 'var(--success)'
    },
    warning: {
      bg: 'var(--warning-subtle)',
      fg: 'var(--amber-600)',
      dotc: 'var(--warning)'
    },
    danger: {
      bg: 'var(--danger-subtle)',
      fg: 'var(--red-600)',
      dotc: 'var(--danger)'
    }
  };
  const t = tones[tone] || tones.neutral;
  return /*#__PURE__*/React.createElement("span", {
    style: {
      display: 'inline-flex',
      alignItems: 'center',
      gap: '6px',
      padding: '4px 11px',
      borderRadius: 'var(--radius-full)',
      background: t.bg,
      color: t.fg,
      fontSize: 'var(--text-caption)',
      fontWeight: 'var(--weight-semibold)',
      letterSpacing: 'var(--tracking-snug)',
      lineHeight: 1.4,
      whiteSpace: 'nowrap',
      ...style
    }
  }, dot && /*#__PURE__*/React.createElement("span", {
    style: {
      width: '6px',
      height: '6px',
      borderRadius: '50%',
      background: t.dotc
    }
  }), children);
}
Object.assign(__ds_scope, { Badge });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/display/Badge.jsx", error: String((e && e.message) || e) }); }

// components/display/Card.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
/**
 * TILKI Card — the core surface container. Soft elevation, generous radius.
 * Set `interactive` for hover lift on clickable cards.
 */
function Card({
  padding = 'md',
  interactive = false,
  elevated = true,
  onClick,
  style = {},
  children,
  ...rest
}) {
  const [hover, setHover] = React.useState(false);
  const pads = {
    none: '0',
    sm: 'var(--space-4)',
    md: 'var(--space-6)',
    lg: 'var(--space-8)'
  };
  return /*#__PURE__*/React.createElement("div", _extends({
    onClick: onClick,
    onMouseEnter: () => setHover(true),
    onMouseLeave: () => setHover(false),
    style: {
      background: 'var(--bg-surface)',
      borderRadius: 'var(--radius-card)',
      border: '1px solid var(--border-subtle)',
      boxShadow: elevated ? interactive && hover ? 'var(--shadow-lg)' : 'var(--shadow-card)' : 'none',
      padding: pads[padding],
      cursor: interactive ? 'pointer' : 'default',
      transform: interactive && hover ? 'translateY(-2px)' : 'translateY(0)',
      transition: 'transform var(--duration-normal) var(--ease-out), box-shadow var(--duration-normal) var(--ease-out)',
      ...style
    }
  }, rest), children);
}
Object.assign(__ds_scope, { Card });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/display/Card.jsx", error: String((e && e.message) || e) }); }

// components/display/StatCard.jsx
try { (() => {
/**
 * TILKI StatCard — a single headline metric with label and optional delta.
 * Uses mono tabular figures for the value.
 */
function StatCard({
  label,
  value,
  unit,
  delta,
  deltaTone = 'success',
  icon = null,
  style = {}
}) {
  const tones = {
    success: 'var(--green-600)',
    danger: 'var(--red-600)',
    neutral: 'var(--text-tertiary)'
  };
  return /*#__PURE__*/React.createElement("div", {
    style: {
      background: 'var(--bg-surface)',
      border: '1px solid var(--border-subtle)',
      borderRadius: 'var(--radius-card)',
      boxShadow: 'var(--shadow-card)',
      padding: 'var(--space-6)',
      display: 'flex',
      flexDirection: 'column',
      gap: 'var(--space-3)',
      ...style
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      alignItems: 'center',
      justifyContent: 'space-between'
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      fontSize: 'var(--text-sm)',
      fontWeight: 'var(--weight-medium)',
      color: 'var(--text-secondary)'
    }
  }, label), icon && /*#__PURE__*/React.createElement("span", {
    style: {
      color: 'var(--text-tertiary)',
      display: 'inline-flex'
    }
  }, icon)), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      alignItems: 'baseline',
      gap: '4px'
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      fontFamily: 'var(--font-mono)',
      fontVariantNumeric: 'tabular-nums',
      fontSize: '34px',
      fontWeight: 'var(--weight-semibold)',
      letterSpacing: '-0.02em',
      color: 'var(--text-primary)',
      whiteSpace: 'nowrap'
    }
  }, value), unit && /*#__PURE__*/React.createElement("span", {
    style: {
      fontSize: 'var(--text-body)',
      color: 'var(--text-tertiary)'
    }
  }, unit)), delta && /*#__PURE__*/React.createElement("span", {
    style: {
      fontSize: 'var(--text-caption)',
      fontWeight: 'var(--weight-semibold)',
      color: tones[deltaTone]
    }
  }, delta));
}
Object.assign(__ds_scope, { StatCard });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/display/StatCard.jsx", error: String((e && e.message) || e) }); }

// components/feedback/Dialog.jsx
try { (() => {
/**
 * TILKI Dialog — centered modal with scrim, soft entrance.
 */
function Dialog({
  open,
  onClose,
  title,
  description,
  footer,
  width = 460,
  children
}) {
  React.useEffect(() => {
    const onKey = e => {
      if (e.key === 'Escape') onClose && onClose();
    };
    if (open) document.addEventListener('keydown', onKey);
    return () => document.removeEventListener('keydown', onKey);
  }, [open, onClose]);
  if (!open) return null;
  return /*#__PURE__*/React.createElement("div", {
    onClick: onClose,
    style: {
      position: 'fixed',
      inset: 0,
      zIndex: 1000,
      background: 'rgba(16,24,40,0.32)',
      backdropFilter: 'blur(3px)',
      display: 'flex',
      alignItems: 'center',
      justifyContent: 'center',
      padding: 'var(--space-6)',
      animation: 'tilki-fade var(--duration-normal) var(--ease-out)'
    }
  }, /*#__PURE__*/React.createElement("div", {
    onClick: e => e.stopPropagation(),
    role: "dialog",
    "aria-modal": "true",
    style: {
      width: '100%',
      maxWidth: `${width}px`,
      background: 'var(--bg-surface)',
      borderRadius: 'var(--radius-xl)',
      boxShadow: 'var(--shadow-xl)',
      padding: 'var(--space-8)',
      display: 'flex',
      flexDirection: 'column',
      gap: 'var(--space-5)',
      animation: 'tilki-pop var(--duration-normal) var(--ease-out)'
    }
  }, (title || description) && /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      flexDirection: 'column',
      gap: 'var(--space-2)'
    }
  }, title && /*#__PURE__*/React.createElement("h3", {
    style: {
      margin: 0
    }
  }, title), description && /*#__PURE__*/React.createElement("p", {
    style: {
      color: 'var(--text-secondary)',
      fontSize: 'var(--text-body)'
    }
  }, description)), children, footer && /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      gap: 'var(--space-3)',
      justifyContent: 'flex-end'
    }
  }, footer)), /*#__PURE__*/React.createElement("style", null, `
        @keyframes tilki-fade { from { opacity: 0 } to { opacity: 1 } }
        @keyframes tilki-pop { from { opacity: 0; transform: translateY(8px) scale(0.98) } to { opacity: 1; transform: none } }
      `));
}
Object.assign(__ds_scope, { Dialog });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/feedback/Dialog.jsx", error: String((e && e.message) || e) }); }

// components/feedback/Tooltip.jsx
try { (() => {
/**
 * TILKI Tooltip — dark hint on hover. Wraps any trigger element.
 */
function Tooltip({
  content,
  side = 'top',
  children,
  style = {}
}) {
  const [show, setShow] = React.useState(false);
  const pos = {
    top: {
      bottom: '100%',
      left: '50%',
      transform: 'translateX(-50%)',
      marginBottom: '8px'
    },
    bottom: {
      top: '100%',
      left: '50%',
      transform: 'translateX(-50%)',
      marginTop: '8px'
    },
    left: {
      right: '100%',
      top: '50%',
      transform: 'translateY(-50%)',
      marginRight: '8px'
    },
    right: {
      left: '100%',
      top: '50%',
      transform: 'translateY(-50%)',
      marginLeft: '8px'
    }
  };
  return /*#__PURE__*/React.createElement("span", {
    style: {
      position: 'relative',
      display: 'inline-flex',
      ...style
    },
    onMouseEnter: () => setShow(true),
    onMouseLeave: () => setShow(false),
    onFocus: () => setShow(true),
    onBlur: () => setShow(false)
  }, children, show && /*#__PURE__*/React.createElement("span", {
    role: "tooltip",
    style: {
      position: 'absolute',
      ...pos[side],
      zIndex: 900,
      whiteSpace: 'nowrap',
      background: 'var(--bg-inverse)',
      color: 'var(--text-on-inverse)',
      fontSize: 'var(--text-caption)',
      fontWeight: 'var(--weight-medium)',
      padding: '7px 11px',
      borderRadius: 'var(--radius-sm)',
      boxShadow: 'var(--shadow-md)',
      pointerEvents: 'none',
      animation: 'tilki-tip var(--duration-fast) var(--ease-out)'
    }
  }, content, /*#__PURE__*/React.createElement("style", null, `@keyframes tilki-tip{from{opacity:0;transform:${(pos[side].transform || '').trim()} scale(0.96)}to{opacity:1}}`)));
}
Object.assign(__ds_scope, { Tooltip });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/feedback/Tooltip.jsx", error: String((e && e.message) || e) }); }

// components/forms/Button.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
/**
 * TILKI Button — the primary action primitive.
 * Pill-shaped, calm transitions, four intents and three sizes.
 */
function Button({
  variant = 'primary',
  size = 'md',
  fullWidth = false,
  disabled = false,
  loading = false,
  iconLeft = null,
  iconRight = null,
  type = 'button',
  onClick,
  style = {},
  children,
  ...rest
}) {
  const sizes = {
    sm: {
      fontSize: '15px',
      padding: '0 16px',
      height: '36px',
      gap: '7px'
    },
    md: {
      fontSize: '17px',
      padding: '0 22px',
      height: '46px',
      gap: '8px'
    },
    lg: {
      fontSize: '18px',
      padding: '0 30px',
      height: '56px',
      gap: '10px'
    }
  };
  const variants = {
    primary: {
      background: 'var(--brand)',
      color: 'var(--text-on-brand)',
      border: '1px solid transparent'
    },
    secondary: {
      background: 'var(--bg-surface)',
      color: 'var(--text-primary)',
      border: '1px solid var(--border)'
    },
    ghost: {
      background: 'transparent',
      color: 'var(--brand)',
      border: '1px solid transparent'
    },
    danger: {
      background: 'var(--danger)',
      color: '#fff',
      border: '1px solid transparent'
    }
  };
  const isDisabled = disabled || loading;
  const base = {
    display: 'inline-flex',
    alignItems: 'center',
    justifyContent: 'center',
    fontFamily: 'var(--font-sans)',
    fontWeight: 'var(--weight-semibold)',
    letterSpacing: 'var(--tracking-snug)',
    borderRadius: 'var(--radius-button)',
    cursor: isDisabled ? 'not-allowed' : 'pointer',
    opacity: isDisabled ? 0.45 : 1,
    width: fullWidth ? '100%' : 'auto',
    transition: 'transform var(--duration-fast) var(--ease-standard), background var(--duration-fast) var(--ease-standard), box-shadow var(--duration-fast) var(--ease-standard)',
    whiteSpace: 'nowrap',
    userSelect: 'none',
    ...sizes[size],
    ...variants[variant],
    ...style
  };
  const [hover, setHover] = React.useState(false);
  const [active, setActive] = React.useState(false);
  const hoverStyle = !isDisabled && hover ? {
    primary: {
      background: 'var(--brand-hover)'
    },
    secondary: {
      background: 'var(--bg-sunken)'
    },
    ghost: {
      background: 'var(--brand-subtle)'
    },
    danger: {
      background: 'var(--red-600)'
    }
  }[variant] : {};
  const activeStyle = !isDisabled && active ? {
    transform: 'scale(0.97)'
  } : {};
  return /*#__PURE__*/React.createElement("button", _extends({
    type: type,
    disabled: isDisabled,
    onClick: onClick,
    onMouseEnter: () => setHover(true),
    onMouseLeave: () => {
      setHover(false);
      setActive(false);
    },
    onMouseDown: () => setActive(true),
    onMouseUp: () => setActive(false),
    style: {
      ...base,
      ...hoverStyle,
      ...activeStyle
    }
  }, rest), loading && /*#__PURE__*/React.createElement(Spinner, null), !loading && iconLeft, children, !loading && iconRight);
}
function Spinner() {
  return /*#__PURE__*/React.createElement("span", {
    style: {
      width: '16px',
      height: '16px',
      borderRadius: '50%',
      border: '2px solid currentColor',
      borderTopColor: 'transparent',
      display: 'inline-block',
      animation: 'tilki-spin 0.7s linear infinite'
    }
  }, /*#__PURE__*/React.createElement("style", null, `@keyframes tilki-spin{to{transform:rotate(360deg)}}`));
}
Object.assign(__ds_scope, { Button });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/forms/Button.jsx", error: String((e && e.message) || e) }); }

// components/forms/Checkbox.jsx
try { (() => {
/**
 * TILKI Checkbox — square with brand fill and check glyph when selected.
 */
function Checkbox({
  checked,
  defaultChecked = false,
  onChange,
  disabled = false,
  label,
  id,
  style = {}
}) {
  const isControlled = checked !== undefined;
  const [internal, setInternal] = React.useState(defaultChecked);
  const on = isControlled ? checked : internal;
  const toggle = () => {
    if (disabled) return;
    if (!isControlled) setInternal(!on);
    onChange && onChange(!on);
  };
  return /*#__PURE__*/React.createElement("label", {
    style: {
      display: 'inline-flex',
      alignItems: 'center',
      gap: '11px',
      cursor: disabled ? 'not-allowed' : 'pointer',
      opacity: disabled ? 0.5 : 1,
      ...style
    }
  }, /*#__PURE__*/React.createElement("span", {
    role: "checkbox",
    "aria-checked": on,
    onClick: toggle,
    style: {
      width: '22px',
      height: '22px',
      flexShrink: 0,
      borderRadius: 'var(--radius-xs)',
      background: on ? 'var(--brand)' : 'var(--bg-surface)',
      border: on ? '1px solid var(--brand)' : '1px solid var(--border-strong)',
      display: 'inline-flex',
      alignItems: 'center',
      justifyContent: 'center',
      transition: 'all var(--duration-fast) var(--ease-standard)'
    }
  }, on && /*#__PURE__*/React.createElement("svg", {
    width: "13",
    height: "13",
    viewBox: "0 0 24 24",
    fill: "none",
    stroke: "#fff",
    strokeWidth: "3.5",
    strokeLinecap: "round",
    strokeLinejoin: "round"
  }, /*#__PURE__*/React.createElement("polyline", {
    points: "20 6 9 17 4 12"
  }))), label && /*#__PURE__*/React.createElement("span", {
    style: {
      fontSize: 'var(--text-body)',
      color: 'var(--text-primary)'
    }
  }, label));
}
Object.assign(__ds_scope, { Checkbox });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/forms/Checkbox.jsx", error: String((e && e.message) || e) }); }

// components/forms/Input.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
/**
 * TILKI Input — labelled text field with optional helper / error and leading icon.
 */
function Input({
  label,
  type = 'text',
  placeholder,
  value,
  defaultValue,
  onChange,
  helper,
  error,
  iconLeft = null,
  disabled = false,
  required = false,
  id,
  style = {},
  ...rest
}) {
  const [focus, setFocus] = React.useState(false);
  const inputId = id || (label ? `in-${label.replace(/\s+/g, '-').toLowerCase()}` : undefined);
  const invalid = Boolean(error);
  const borderColor = invalid ? 'var(--danger)' : focus ? 'var(--brand)' : 'var(--border)';
  return /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      flexDirection: 'column',
      gap: '7px',
      width: '100%',
      ...style
    }
  }, label && /*#__PURE__*/React.createElement("label", {
    htmlFor: inputId,
    style: {
      fontSize: 'var(--text-sm)',
      fontWeight: 'var(--weight-semibold)',
      color: 'var(--text-primary)',
      letterSpacing: 'var(--tracking-snug)'
    }
  }, label, required && /*#__PURE__*/React.createElement("span", {
    style: {
      color: 'var(--danger)',
      marginLeft: '3px'
    }
  }, "*")), /*#__PURE__*/React.createElement("div", {
    style: {
      position: 'relative',
      display: 'flex',
      alignItems: 'center'
    }
  }, iconLeft && /*#__PURE__*/React.createElement("span", {
    style: {
      position: 'absolute',
      left: '14px',
      display: 'inline-flex',
      color: focus ? 'var(--brand)' : 'var(--text-tertiary)',
      pointerEvents: 'none'
    }
  }, iconLeft), /*#__PURE__*/React.createElement("input", _extends({
    id: inputId,
    type: type,
    placeholder: placeholder,
    value: value,
    defaultValue: defaultValue,
    onChange: onChange,
    disabled: disabled,
    required: required,
    onFocus: () => setFocus(true),
    onBlur: () => setFocus(false),
    style: {
      width: '100%',
      height: '46px',
      padding: iconLeft ? '0 16px 0 42px' : '0 16px',
      fontFamily: 'var(--font-sans)',
      fontSize: 'var(--text-body)',
      color: 'var(--text-primary)',
      background: disabled ? 'var(--bg-sunken)' : 'var(--bg-surface)',
      border: `1px solid ${borderColor}`,
      borderRadius: 'var(--radius-input)',
      outline: 'none',
      boxShadow: focus ? 'var(--shadow-focus)' : 'none',
      transition: 'border-color var(--duration-fast) var(--ease-standard), box-shadow var(--duration-fast) var(--ease-standard)',
      opacity: disabled ? 0.55 : 1,
      cursor: disabled ? 'not-allowed' : 'text'
    }
  }, rest))), (error || helper) && /*#__PURE__*/React.createElement("span", {
    style: {
      fontSize: 'var(--text-caption)',
      color: invalid ? 'var(--danger)' : 'var(--text-tertiary)'
    }
  }, error || helper));
}
Object.assign(__ds_scope, { Input });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/forms/Input.jsx", error: String((e && e.message) || e) }); }

// components/forms/Select.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
/**
 * TILKI Select — native select styled to match Input, with chevron.
 */
function Select({
  label,
  value,
  defaultValue,
  onChange,
  options = [],
  placeholder,
  disabled = false,
  error,
  id,
  style = {},
  ...rest
}) {
  const [focus, setFocus] = React.useState(false);
  const selectId = id || (label ? `sel-${label.replace(/\s+/g, '-').toLowerCase()}` : undefined);
  const invalid = Boolean(error);
  const borderColor = invalid ? 'var(--danger)' : focus ? 'var(--brand)' : 'var(--border)';
  const opts = options.map(o => typeof o === 'string' ? {
    value: o,
    label: o
  } : o);
  return /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      flexDirection: 'column',
      gap: '7px',
      width: '100%',
      ...style
    }
  }, label && /*#__PURE__*/React.createElement("label", {
    htmlFor: selectId,
    style: {
      fontSize: 'var(--text-sm)',
      fontWeight: 'var(--weight-semibold)',
      color: 'var(--text-primary)'
    }
  }, label), /*#__PURE__*/React.createElement("div", {
    style: {
      position: 'relative'
    }
  }, /*#__PURE__*/React.createElement("select", _extends({
    id: selectId,
    value: value,
    defaultValue: defaultValue,
    onChange: onChange,
    disabled: disabled,
    onFocus: () => setFocus(true),
    onBlur: () => setFocus(false),
    style: {
      width: '100%',
      height: '46px',
      padding: '0 42px 0 16px',
      fontFamily: 'var(--font-sans)',
      fontSize: 'var(--text-body)',
      color: 'var(--text-primary)',
      background: disabled ? 'var(--bg-sunken)' : 'var(--bg-surface)',
      border: `1px solid ${borderColor}`,
      borderRadius: 'var(--radius-input)',
      outline: 'none',
      boxShadow: focus ? 'var(--shadow-focus)' : 'none',
      appearance: 'none',
      WebkitAppearance: 'none',
      cursor: disabled ? 'not-allowed' : 'pointer',
      transition: 'border-color var(--duration-fast) var(--ease-standard), box-shadow var(--duration-fast) var(--ease-standard)'
    }
  }, rest), placeholder && /*#__PURE__*/React.createElement("option", {
    value: "",
    disabled: true
  }, placeholder), opts.map(o => /*#__PURE__*/React.createElement("option", {
    key: o.value,
    value: o.value
  }, o.label))), /*#__PURE__*/React.createElement("span", {
    style: {
      position: 'absolute',
      right: '16px',
      top: '50%',
      transform: 'translateY(-50%)',
      pointerEvents: 'none',
      color: 'var(--text-tertiary)'
    }
  }, /*#__PURE__*/React.createElement("svg", {
    width: "16",
    height: "16",
    viewBox: "0 0 24 24",
    fill: "none",
    stroke: "currentColor",
    strokeWidth: "2.2",
    strokeLinecap: "round",
    strokeLinejoin: "round"
  }, /*#__PURE__*/React.createElement("polyline", {
    points: "6 9 12 15 18 9"
  })))), error && /*#__PURE__*/React.createElement("span", {
    style: {
      fontSize: 'var(--text-caption)',
      color: 'var(--danger)'
    }
  }, error));
}
Object.assign(__ds_scope, { Select });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/forms/Select.jsx", error: String((e && e.message) || e) }); }

// components/forms/Switch.jsx
try { (() => {
/**
 * TILKI Switch — iOS-style toggle. Calm slide, brand-blue when on.
 */
function Switch({
  checked,
  defaultChecked = false,
  onChange,
  disabled = false,
  label,
  id,
  style = {}
}) {
  const isControlled = checked !== undefined;
  const [internal, setInternal] = React.useState(defaultChecked);
  const on = isControlled ? checked : internal;
  const toggle = () => {
    if (disabled) return;
    if (!isControlled) setInternal(!on);
    onChange && onChange(!on);
  };
  const control = /*#__PURE__*/React.createElement("button", {
    type: "button",
    role: "switch",
    "aria-checked": on,
    onClick: toggle,
    disabled: disabled,
    style: {
      width: '52px',
      height: '32px',
      flexShrink: 0,
      borderRadius: 'var(--radius-full)',
      border: 'none',
      padding: 0,
      background: on ? 'var(--brand)' : 'var(--neutral-300)',
      cursor: disabled ? 'not-allowed' : 'pointer',
      opacity: disabled ? 0.5 : 1,
      position: 'relative',
      transition: 'background var(--duration-normal) var(--ease-standard)'
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      position: 'absolute',
      top: '3px',
      left: on ? '23px' : '3px',
      width: '26px',
      height: '26px',
      borderRadius: '50%',
      background: '#fff',
      boxShadow: '0 2px 5px rgba(0,0,0,0.2)',
      transition: 'left var(--duration-normal) var(--ease-out)'
    }
  }));
  if (!label) return control;
  return /*#__PURE__*/React.createElement("label", {
    style: {
      display: 'inline-flex',
      alignItems: 'center',
      gap: '12px',
      cursor: disabled ? 'not-allowed' : 'pointer',
      ...style
    }
  }, control, /*#__PURE__*/React.createElement("span", {
    style: {
      fontSize: 'var(--text-body)',
      color: 'var(--text-primary)'
    }
  }, label));
}
Object.assign(__ds_scope, { Switch });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/forms/Switch.jsx", error: String((e && e.message) || e) }); }

// components/navigation/Tabs.jsx
try { (() => {
/**
 * TILKI Tabs — segmented underline tabs. Controlled or uncontrolled.
 * `tabs` is an array of { value, label } or strings.
 */
function Tabs({
  tabs = [],
  value,
  defaultValue,
  onChange,
  style = {}
}) {
  const items = tabs.map(t => typeof t === 'string' ? {
    value: t,
    label: t
  } : t);
  const isControlled = value !== undefined;
  const [internal, setInternal] = React.useState(defaultValue ?? items[0]?.value);
  const active = isControlled ? value : internal;
  const select = v => {
    if (!isControlled) setInternal(v);
    onChange && onChange(v);
  };
  return /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      gap: 'var(--space-6)',
      borderBottom: '1px solid var(--border-subtle)',
      ...style
    }
  }, items.map(t => {
    const on = t.value === active;
    return /*#__PURE__*/React.createElement("button", {
      key: t.value,
      type: "button",
      onClick: () => select(t.value),
      style: {
        appearance: 'none',
        background: 'none',
        border: 'none',
        cursor: 'pointer',
        padding: '0 0 14px',
        position: 'relative',
        fontFamily: 'var(--font-sans)',
        fontSize: 'var(--text-body)',
        fontWeight: on ? 'var(--weight-semibold)' : 'var(--weight-medium)',
        color: on ? 'var(--text-primary)' : 'var(--text-secondary)',
        transition: 'color var(--duration-fast) var(--ease-standard)'
      }
    }, t.label, /*#__PURE__*/React.createElement("span", {
      style: {
        position: 'absolute',
        left: 0,
        right: 0,
        bottom: '-1px',
        height: '2px',
        borderRadius: '2px',
        background: 'var(--brand)',
        transform: on ? 'scaleX(1)' : 'scaleX(0)',
        transition: 'transform var(--duration-normal) var(--ease-out)'
      }
    }));
  }));
}
Object.assign(__ds_scope, { Tabs });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/navigation/Tabs.jsx", error: String((e && e.message) || e) }); }

// ui_kits/tilki-app/AppShell.jsx
try { (() => {
// TILKI app shell — sidebar + top bar. Composes bundle Icon + Avatar.
const {
  Icon,
  Avatar
} = window.TILKIDesignSystem_7dda08;
function AppShell({
  active,
  onNav,
  onQuote,
  children
}) {
  const nav = [{
    id: 'dashboard',
    icon: 'layout-grid',
    label: 'Accueil'
  }, {
    id: 'policies',
    icon: 'shield',
    label: 'Contrats'
  }, {
    id: 'claims',
    icon: 'file-text',
    label: 'Sinistres'
  }, {
    id: 'documents',
    icon: 'folder',
    label: 'Documents'
  }, {
    id: 'messages',
    icon: 'message-circle',
    label: 'Messages'
  }];
  return /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      height: '100%',
      background: 'var(--bg-page)'
    }
  }, /*#__PURE__*/React.createElement("aside", {
    style: {
      width: 248,
      flexShrink: 0,
      background: 'var(--bg-surface)',
      borderRight: '1px solid var(--border-subtle)',
      padding: '24px 16px',
      display: 'flex',
      flexDirection: 'column',
      gap: 4
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      alignItems: 'center',
      gap: 9,
      padding: '4px 8px 22px'
    }
  }, /*#__PURE__*/React.createElement("img", {
    src: window.__resources && window.__resources.logoMark || "../../assets/logo-mark.png",
    alt: "",
    style: {
      height: 26
    }
  }), /*#__PURE__*/React.createElement("img", {
    src: window.__resources && window.__resources.logoWordmark || "../../assets/logo-wordmark.png",
    alt: "TILKI",
    style: {
      height: 18
    }
  })), nav.map(n => {
    const on = active === n.id;
    return /*#__PURE__*/React.createElement("button", {
      key: n.id,
      onClick: () => onNav(n.id),
      style: {
        display: 'flex',
        alignItems: 'center',
        gap: 12,
        width: '100%',
        padding: '11px 12px',
        borderRadius: 'var(--radius-md)',
        border: 'none',
        background: on ? 'var(--brand-subtle)' : 'transparent',
        color: on ? 'var(--brand)' : 'var(--text-secondary)',
        fontFamily: 'var(--font-sans)',
        fontSize: 'var(--text-body)',
        fontWeight: on ? 'var(--weight-semibold)' : 'var(--weight-medium)',
        cursor: 'pointer',
        textAlign: 'left',
        transition: 'background var(--duration-fast) var(--ease-standard)'
      }
    }, /*#__PURE__*/React.createElement(Icon, {
      name: n.icon,
      size: 20,
      strokeWidth: on ? 2.2 : 1.9
    }), n.label);
  }), /*#__PURE__*/React.createElement("div", {
    style: {
      flex: 1
    }
  }), /*#__PURE__*/React.createElement(AdvisorMini, null)), /*#__PURE__*/React.createElement("div", {
    style: {
      flex: 1,
      display: 'flex',
      flexDirection: 'column',
      minWidth: 0
    }
  }, /*#__PURE__*/React.createElement("header", {
    style: {
      height: 72,
      flexShrink: 0,
      display: 'flex',
      alignItems: 'center',
      gap: 16,
      padding: '0 32px',
      borderBottom: '1px solid var(--border-subtle)',
      background: 'var(--bg-surface)'
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      flex: 1,
      maxWidth: 420,
      display: 'flex',
      alignItems: 'center',
      gap: 10,
      height: 42,
      padding: '0 16px',
      borderRadius: 'var(--radius-full)',
      background: 'var(--bg-page)',
      color: 'var(--text-tertiary)'
    }
  }, /*#__PURE__*/React.createElement(Icon, {
    name: "search",
    size: 18
  }), /*#__PURE__*/React.createElement("span", {
    style: {
      fontSize: 'var(--text-sm)'
    }
  }, "Rechercher un contrat, un sinistre, un document\u2026")), /*#__PURE__*/React.createElement("div", {
    style: {
      flex: 1
    }
  }), /*#__PURE__*/React.createElement("button", {
    onClick: onQuote,
    style: {
      display: 'inline-flex',
      alignItems: 'center',
      gap: 8,
      height: 42,
      padding: '0 20px',
      borderRadius: 'var(--radius-full)',
      border: 'none',
      background: 'var(--brand)',
      color: '#fff',
      fontFamily: 'var(--font-sans)',
      fontSize: 'var(--text-sm)',
      fontWeight: 'var(--weight-semibold)',
      cursor: 'pointer',
      whiteSpace: 'nowrap'
    }
  }, /*#__PURE__*/React.createElement(Icon, {
    name: "plus",
    size: 18
  }), " Nouveau devis"), /*#__PURE__*/React.createElement("button", {
    style: {
      display: 'inline-flex',
      width: 42,
      height: 42,
      borderRadius: '50%',
      border: '1px solid var(--border)',
      background: 'var(--bg-surface)',
      alignItems: 'center',
      justifyContent: 'center',
      color: 'var(--text-secondary)',
      cursor: 'pointer'
    }
  }, /*#__PURE__*/React.createElement(Icon, {
    name: "bell",
    size: 19
  })), /*#__PURE__*/React.createElement(Avatar, {
    name: window.TILKI_DATA.user.name,
    size: "md"
  })), /*#__PURE__*/React.createElement("main", {
    style: {
      flex: 1,
      overflowY: 'auto'
    }
  }, children)));
}
function AdvisorMini() {
  const a = window.TILKI_DATA.advisor;
  return /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      alignItems: 'center',
      gap: 11,
      padding: 12,
      borderRadius: 'var(--radius-md)',
      background: 'var(--bg-page)'
    }
  }, /*#__PURE__*/React.createElement(Avatar, {
    name: a.name,
    size: "md"
  }), /*#__PURE__*/React.createElement("div", {
    style: {
      minWidth: 0
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      fontSize: 'var(--text-sm)',
      fontWeight: 'var(--weight-semibold)'
    }
  }, a.name), /*#__PURE__*/React.createElement("div", {
    style: {
      fontSize: 'var(--text-caption)',
      color: 'var(--text-tertiary)'
    }
  }, a.role)));
}
Object.assign(window, {
  AppShell
});
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/tilki-app/AppShell.jsx", error: String((e && e.message) || e) }); }

// ui_kits/tilki-app/Dashboard.jsx
try { (() => {
// TILKI dashboard — greeting, premium summary, policy grid, advisor.
const {
  Icon,
  Card,
  StatCard,
  Badge,
  Button
} = window.TILKIDesignSystem_7dda08;
function statusBadge(status) {
  if (status === 'active') return /*#__PURE__*/React.createElement(Badge, {
    tone: "success",
    dot: true
  }, "Actif");
  if (status === 'renewal') return /*#__PURE__*/React.createElement(Badge, {
    tone: "warning",
    dot: true
  }, "\xC0 renouveler");
  if (status === 'lapsed') return /*#__PURE__*/React.createElement(Badge, {
    tone: "danger",
    dot: true
  }, "R\xE9sili\xE9");
  return /*#__PURE__*/React.createElement(Badge, null, "Brouillon");
}
function PolicyCard({
  p,
  onOpen
}) {
  return /*#__PURE__*/React.createElement(Card, {
    interactive: true,
    padding: "md",
    onClick: () => onOpen(p),
    style: {
      display: 'flex',
      flexDirection: 'column',
      gap: 16
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      alignItems: 'flex-start',
      justifyContent: 'space-between'
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      gap: 13,
      alignItems: 'center'
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      width: 46,
      height: 46,
      borderRadius: 13,
      background: 'var(--brand-subtle)',
      color: 'var(--brand)',
      display: 'flex',
      alignItems: 'center',
      justifyContent: 'center'
    }
  }, /*#__PURE__*/React.createElement(Icon, {
    name: p.icon,
    size: 24,
    strokeWidth: 1.9
  })), /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement("div", {
    style: {
      fontWeight: 'var(--weight-semibold)',
      fontSize: 'var(--text-body)'
    }
  }, p.name), /*#__PURE__*/React.createElement("div", {
    style: {
      fontSize: 'var(--text-sm)',
      color: 'var(--text-tertiary)'
    }
  }, p.provider))), statusBadge(p.status)), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      alignItems: 'flex-end',
      justifyContent: 'space-between'
    }
  }, /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement("span", {
    style: {
      fontFamily: 'var(--font-mono)',
      fontVariantNumeric: 'tabular-nums',
      fontSize: 26,
      fontWeight: 'var(--weight-semibold)',
      letterSpacing: '-0.02em'
    }
  }, p.premium), /*#__PURE__*/React.createElement("span", {
    style: {
      color: 'var(--text-tertiary)',
      fontSize: 'var(--text-sm)'
    }
  }, p.cycle)), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      alignItems: 'center',
      gap: 6,
      color: 'var(--text-secondary)',
      fontSize: 'var(--text-sm)'
    }
  }, /*#__PURE__*/React.createElement(Icon, {
    name: "calendar",
    size: 15
  }), " ", p.renews)));
}
function Dashboard({
  onOpenPolicy,
  onQuote
}) {
  const d = window.TILKI_DATA;
  return /*#__PURE__*/React.createElement("div", {
    style: {
      maxWidth: 1080,
      margin: '0 auto',
      padding: '40px 32px 64px'
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      alignItems: 'flex-end',
      justifyContent: 'space-between',
      marginBottom: 28
    }
  }, /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement("div", {
    style: {
      fontSize: 'var(--text-sm)',
      color: 'var(--text-tertiary)',
      fontWeight: 'var(--weight-medium)',
      marginBottom: 4
    }
  }, "Bon apr\xE8s-midi"), /*#__PURE__*/React.createElement("h1", {
    style: {
      fontSize: 'var(--text-h1)'
    }
  }, d.user.name.split(' ')[0], ", vous \xEAtes bien couverte."))), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'grid',
      gridTemplateColumns: 'repeat(3,1fr)',
      gap: 16,
      marginBottom: 36
    }
  }, /*#__PURE__*/React.createElement(StatCard, {
    label: "Cotisation annuelle totale",
    value: "546 000 FCFA",
    unit: "/an",
    delta: "\u2193 6 % apr\xE8s votre dernier bilan",
    deltaTone: "success"
  }), /*#__PURE__*/React.createElement(StatCard, {
    label: "Contrats actifs",
    value: 4,
    icon: /*#__PURE__*/React.createElement(Icon, {
      name: "shield",
      size: 20
    })
  }), /*#__PURE__*/React.createElement(StatCard, {
    label: "Prochaine \xE9ch\xE9ance",
    value: "21 janv.",
    delta: "Voyage \xB7 26 jours",
    deltaTone: "neutral",
    icon: /*#__PURE__*/React.createElement(Icon, {
      name: "calendar",
      size: 20
    })
  })), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      alignItems: 'center',
      justifyContent: 'space-between',
      marginBottom: 16
    }
  }, /*#__PURE__*/React.createElement("h3", null, "Vos contrats"), /*#__PURE__*/React.createElement(Button, {
    variant: "ghost",
    size: "sm",
    iconRight: /*#__PURE__*/React.createElement(Icon, {
      name: "arrow-right",
      size: 17
    }),
    onClick: onQuote
  }, "Ajouter une garantie")), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'grid',
      gridTemplateColumns: 'repeat(2,1fr)',
      gap: 16
    }
  }, d.policies.map(p => /*#__PURE__*/React.createElement(PolicyCard, {
    key: p.id,
    p: p,
    onOpen: onOpenPolicy
  }))), /*#__PURE__*/React.createElement(AdvisorBanner, null));
}
function AdvisorBanner() {
  const a = window.TILKI_DATA.advisor;
  return /*#__PURE__*/React.createElement("div", {
    style: {
      marginTop: 28,
      padding: 24,
      borderRadius: 'var(--radius-lg)',
      background: 'var(--bg-inverse)',
      color: '#fff',
      display: 'flex',
      alignItems: 'center',
      gap: 20
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      width: 52,
      height: 52,
      borderRadius: '50%',
      background: 'rgba(255,255,255,.14)',
      display: 'flex',
      alignItems: 'center',
      justifyContent: 'center'
    }
  }, /*#__PURE__*/React.createElement(Icon, {
    name: "umbrella",
    size: 26,
    color: "#fff"
  })), /*#__PURE__*/React.createElement("div", {
    style: {
      flex: 1
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      fontWeight: 'var(--weight-semibold)',
      fontSize: 'var(--text-body-lg)'
    }
  }, "\xC9changez avec ", a.name.split(' ')[0]), /*#__PURE__*/React.createElement("div", {
    style: {
      color: 'rgba(255,255,255,.7)',
      fontSize: 'var(--text-sm)'
    }
  }, "Nos experts analysent vos risques et revoient vos garanties chaque ann\xE9e \u2014 ici, \xE0 Abidjan.")), /*#__PURE__*/React.createElement("button", {
    style: {
      display: 'inline-flex',
      alignItems: 'center',
      gap: 8,
      height: 44,
      padding: '0 22px',
      borderRadius: 'var(--radius-full)',
      border: 'none',
      background: '#fff',
      color: 'var(--text-primary)',
      fontFamily: 'var(--font-sans)',
      fontWeight: 'var(--weight-semibold)',
      fontSize: 'var(--text-sm)',
      cursor: 'pointer'
    }
  }, /*#__PURE__*/React.createElement(Icon, {
    name: "phone",
    size: 17
  }), " Prendre rendez-vous"));
}
Object.assign(window, {
  Dashboard
});
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/tilki-app/Dashboard.jsx", error: String((e && e.message) || e) }); }

// ui_kits/tilki-app/PolicyDetail.jsx
try { (() => {
// TILKI policy detail — header, tabs, coverage summary, documents.
const {
  Icon,
  Card,
  Badge,
  Button,
  Tabs,
  Switch
} = window.TILKIDesignSystem_7dda08;
function Row({
  label,
  value,
  mono
}) {
  return /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      justifyContent: 'space-between',
      alignItems: 'center',
      padding: '14px 0',
      borderBottom: '1px solid var(--border-subtle)'
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      color: 'var(--text-secondary)',
      fontSize: 'var(--text-sm)'
    }
  }, label), /*#__PURE__*/React.createElement("span", {
    style: {
      fontWeight: 'var(--weight-medium)',
      fontFamily: mono ? 'var(--font-mono)' : 'inherit',
      fontSize: mono ? 'var(--text-sm)' : 'var(--text-body)'
    }
  }, value));
}
function PolicyDetail({
  policy,
  onBack
}) {
  const [tab, setTab] = React.useState('Overview');
  const p = policy;
  return /*#__PURE__*/React.createElement("div", {
    style: {
      maxWidth: 880,
      margin: '0 auto',
      padding: '28px 32px 64px'
    }
  }, /*#__PURE__*/React.createElement("button", {
    onClick: onBack,
    style: {
      display: 'inline-flex',
      alignItems: 'center',
      gap: 7,
      border: 'none',
      background: 'none',
      color: 'var(--text-secondary)',
      fontFamily: 'var(--font-sans)',
      fontSize: 'var(--text-sm)',
      cursor: 'pointer',
      padding: 0,
      marginBottom: 22
    }
  }, /*#__PURE__*/React.createElement(Icon, {
    name: "chevron-left",
    size: 18
  }), " Tous les contrats"), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      alignItems: 'center',
      gap: 16,
      marginBottom: 26
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      width: 56,
      height: 56,
      borderRadius: 16,
      background: 'var(--brand-subtle)',
      color: 'var(--brand)',
      display: 'flex',
      alignItems: 'center',
      justifyContent: 'center'
    }
  }, /*#__PURE__*/React.createElement(Icon, {
    name: p.icon,
    size: 28,
    strokeWidth: 1.9
  })), /*#__PURE__*/React.createElement("div", {
    style: {
      flex: 1
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      alignItems: 'center',
      gap: 12
    }
  }, /*#__PURE__*/React.createElement("h2", {
    style: {
      fontSize: 'var(--text-h2)'
    }
  }, p.name), p.status === 'renewal' ? /*#__PURE__*/React.createElement(Badge, {
    tone: "warning",
    dot: true
  }, "\xC0 renouveler") : /*#__PURE__*/React.createElement(Badge, {
    tone: "success",
    dot: true
  }, "Actif")), /*#__PURE__*/React.createElement("div", {
    style: {
      color: 'var(--text-tertiary)',
      fontSize: 'var(--text-sm)'
    }
  }, p.provider, " \xB7 ", p.cover)), /*#__PURE__*/React.createElement(Button, {
    variant: "secondary",
    iconLeft: /*#__PURE__*/React.createElement(Icon, {
      name: "download",
      size: 18
    })
  }, "Documents")), /*#__PURE__*/React.createElement(Tabs, {
    tabs: ['Aperçu', 'Documents', 'Sinistres'],
    value: tab,
    onChange: setTab,
    style: {
      marginBottom: 24
    }
  }), tab === 'Aperçu' && /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'grid',
      gridTemplateColumns: '1.4fr 1fr',
      gap: 20
    }
  }, /*#__PURE__*/React.createElement(Card, {
    padding: "lg"
  }, /*#__PURE__*/React.createElement("h4", {
    style: {
      marginBottom: 8
    }
  }, "Garanties"), /*#__PURE__*/React.createElement(Row, {
    label: "Type de garantie",
    value: p.cover
  }), /*#__PURE__*/React.createElement(Row, {
    label: "N\xB0 de contrat",
    value: p.ref,
    mono: true
  }), /*#__PURE__*/React.createElement(Row, {
    label: "Assureur",
    value: p.provider
  }), /*#__PURE__*/React.createElement(Row, {
    label: "\xC9ch\xE9ance",
    value: p.renews
  }), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      justifyContent: 'space-between',
      alignItems: 'center',
      paddingTop: 16
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      color: 'var(--text-secondary)',
      fontSize: 'var(--text-sm)'
    }
  }, "Renouvellement auto."), /*#__PURE__*/React.createElement(Switch, {
    defaultChecked: true
  }))), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      flexDirection: 'column',
      gap: 20
    }
  }, /*#__PURE__*/React.createElement(Card, {
    padding: "lg",
    style: {
      background: 'var(--brand)',
      color: '#fff',
      border: 'none'
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      fontSize: 'var(--text-sm)',
      opacity: .8
    }
  }, "Votre cotisation"), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      alignItems: 'baseline',
      gap: 4,
      margin: '6px 0 2px'
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      fontFamily: 'var(--font-mono)',
      fontVariantNumeric: 'tabular-nums',
      fontSize: 40,
      fontWeight: 'var(--weight-bold)',
      letterSpacing: '-0.03em'
    }
  }, p.premium), /*#__PURE__*/React.createElement("span", {
    style: {
      opacity: .8
    }
  }, p.cycle)), /*#__PURE__*/React.createElement("div", {
    style: {
      fontSize: 'var(--text-sm)',
      opacity: .8
    }
  }, p.annual, " pr\xE9lev\xE9s par an")), /*#__PURE__*/React.createElement(Card, {
    padding: "md",
    style: {
      display: 'flex',
      alignItems: 'center',
      gap: 12
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      width: 40,
      height: 40,
      borderRadius: 11,
      background: 'var(--success-subtle)',
      color: 'var(--green-600)',
      display: 'flex',
      alignItems: 'center',
      justifyContent: 'center'
    }
  }, /*#__PURE__*/React.createElement(Icon, {
    name: "check-circle",
    size: 22
  })), /*#__PURE__*/React.createElement("div", {
    style: {
      fontSize: 'var(--text-sm)'
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      fontWeight: 'var(--weight-semibold)'
    }
  }, "Enti\xE8rement prot\xE9g\xE9e"), /*#__PURE__*/React.createElement("div", {
    style: {
      color: 'var(--text-tertiary)'
    }
  }, "Aucune lacune dans vos garanties"))))), tab === 'Documents' && /*#__PURE__*/React.createElement(Card, {
    padding: "none"
  }, [['Conditions particulières 2026', 'PDF · 240 Ko'], ['Attestation d’assurance', 'PDF · 88 Ko'], ['Conditions générales', 'PDF · 1,2 Mo']].map(([n, m], i) => /*#__PURE__*/React.createElement("div", {
    key: i,
    style: {
      display: 'flex',
      alignItems: 'center',
      gap: 14,
      padding: '18px 22px',
      borderBottom: i < 2 ? '1px solid var(--border-subtle)' : 'none'
    }
  }, /*#__PURE__*/React.createElement(Icon, {
    name: "file-text",
    size: 22,
    color: "var(--brand)"
  }), /*#__PURE__*/React.createElement("div", {
    style: {
      flex: 1
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      fontWeight: 'var(--weight-medium)'
    }
  }, n), /*#__PURE__*/React.createElement("div", {
    style: {
      fontSize: 'var(--text-caption)',
      color: 'var(--text-tertiary)'
    }
  }, m)), /*#__PURE__*/React.createElement(Icon, {
    name: "download",
    size: 20,
    color: "var(--text-tertiary)"
  })))), tab === 'Sinistres' && /*#__PURE__*/React.createElement(Card, {
    padding: "lg",
    style: {
      textAlign: 'center',
      padding: '48px 24px'
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      width: 56,
      height: 56,
      margin: '0 auto 14px',
      borderRadius: '50%',
      background: 'var(--bg-page)',
      display: 'flex',
      alignItems: 'center',
      justifyContent: 'center'
    }
  }, /*#__PURE__*/React.createElement(Icon, {
    name: "shield-check",
    size: 28,
    color: "var(--text-tertiary)"
  })), /*#__PURE__*/React.createElement("div", {
    style: {
      fontWeight: 'var(--weight-semibold)',
      fontSize: 'var(--text-body-lg)'
    }
  }, "Aucun sinistre sur ce contrat"), /*#__PURE__*/React.createElement("div", {
    style: {
      color: 'var(--text-tertiary)',
      marginTop: 4
    }
  }, "En cas de probl\xE8me, vous d\xE9clarez un sinistre en quelques minutes."), /*#__PURE__*/React.createElement("div", {
    style: {
      marginTop: 20
    }
  }, /*#__PURE__*/React.createElement(Button, {
    variant: "secondary"
  }, "D\xE9clarer un sinistre"))));
}
Object.assign(window, {
  PolicyDetail
});
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/tilki-app/PolicyDetail.jsx", error: String((e && e.message) || e) }); }

// ui_kits/tilki-app/QuoteFlow.jsx
try { (() => {
// TILKI quote flow — 3 steps: choose cover, a few details, compare quotes.
const {
  Icon,
  Card,
  Button,
  Input,
  Select,
  Badge
} = window.TILKIDesignSystem_7dda08;
function Stepper({
  step
}) {
  const labels = ['Garantie', 'Détails', 'Comparer'];
  return /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      alignItems: 'center',
      gap: 10,
      justifyContent: 'center',
      marginBottom: 36
    }
  }, labels.map((l, i) => {
    const done = i < step,
      on = i === step;
    return /*#__PURE__*/React.createElement(React.Fragment, {
      key: l
    }, /*#__PURE__*/React.createElement("div", {
      style: {
        display: 'flex',
        alignItems: 'center',
        gap: 8
      }
    }, /*#__PURE__*/React.createElement("div", {
      style: {
        width: 26,
        height: 26,
        borderRadius: '50%',
        display: 'flex',
        alignItems: 'center',
        justifyContent: 'center',
        fontSize: 13,
        fontWeight: 'var(--weight-semibold)',
        background: done || on ? 'var(--brand)' : 'var(--bg-sunken)',
        color: done || on ? '#fff' : 'var(--text-tertiary)'
      }
    }, done ? /*#__PURE__*/React.createElement(Icon, {
      name: "check",
      size: 15
    }) : i + 1), /*#__PURE__*/React.createElement("span", {
      style: {
        fontSize: 'var(--text-sm)',
        fontWeight: on ? 'var(--weight-semibold)' : 'var(--weight-medium)',
        color: on || done ? 'var(--text-primary)' : 'var(--text-tertiary)'
      }
    }, l)), i < labels.length - 1 && /*#__PURE__*/React.createElement("div", {
      style: {
        width: 36,
        height: 2,
        background: done ? 'var(--brand)' : 'var(--border)'
      }
    }));
  }));
}
function QuoteFlow({
  onClose
}) {
  const d = window.TILKI_DATA;
  const [step, setStep] = React.useState(0);
  const [type, setType] = React.useState(null);
  return /*#__PURE__*/React.createElement("div", {
    style: {
      minHeight: '100%',
      background: 'var(--bg-page)'
    }
  }, /*#__PURE__*/React.createElement("header", {
    style: {
      height: 72,
      display: 'flex',
      alignItems: 'center',
      justifyContent: 'space-between',
      padding: '0 32px',
      borderBottom: '1px solid var(--border-subtle)',
      background: 'var(--bg-surface)'
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      alignItems: 'center',
      gap: 9
    }
  }, /*#__PURE__*/React.createElement("img", {
    src: window.__resources && window.__resources.logoMark || "../../assets/logo-mark.png",
    alt: "",
    style: {
      height: 24
    }
  }), /*#__PURE__*/React.createElement("span", {
    style: {
      fontWeight: 'var(--weight-semibold)'
    }
  }, "Obtenir un devis")), /*#__PURE__*/React.createElement("button", {
    onClick: onClose,
    style: {
      width: 40,
      height: 40,
      borderRadius: '50%',
      border: '1px solid var(--border)',
      background: 'var(--bg-surface)',
      display: 'flex',
      alignItems: 'center',
      justifyContent: 'center',
      cursor: 'pointer',
      color: 'var(--text-secondary)'
    }
  }, /*#__PURE__*/React.createElement(Icon, {
    name: "x",
    size: 20
  }))), /*#__PURE__*/React.createElement("div", {
    style: {
      maxWidth: 720,
      margin: '0 auto',
      padding: '44px 24px 64px'
    }
  }, /*#__PURE__*/React.createElement(Stepper, {
    step: step
  }), step === 0 && /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement("h2", {
    style: {
      textAlign: 'center',
      marginBottom: 6
    }
  }, "Que souhaitez-vous assurer ?"), /*#__PURE__*/React.createElement("p", {
    style: {
      textAlign: 'center',
      color: 'var(--text-secondary)',
      marginBottom: 30
    }
  }, "Nous comparons des assureurs de confiance pour trouver votre meilleur prix."), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'grid',
      gridTemplateColumns: 'repeat(2,1fr)',
      gap: 14
    }
  }, d.quoteTypes.map(t => {
    const on = type === t.id;
    return /*#__PURE__*/React.createElement(Card, {
      key: t.id,
      interactive: true,
      padding: "md",
      onClick: () => setType(t.id),
      style: {
        display: 'flex',
        alignItems: 'center',
        gap: 14,
        borderColor: on ? 'var(--brand)' : 'var(--border-subtle)',
        boxShadow: on ? 'var(--shadow-focus)' : 'var(--shadow-card)'
      }
    }, /*#__PURE__*/React.createElement("div", {
      style: {
        width: 48,
        height: 48,
        borderRadius: 13,
        background: on ? 'var(--brand)' : 'var(--brand-subtle)',
        color: on ? '#fff' : 'var(--brand)',
        display: 'flex',
        alignItems: 'center',
        justifyContent: 'center'
      }
    }, /*#__PURE__*/React.createElement(Icon, {
      name: t.icon,
      size: 24,
      strokeWidth: 1.9
    })), /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement("div", {
      style: {
        fontWeight: 'var(--weight-semibold)'
      }
    }, t.label), /*#__PURE__*/React.createElement("div", {
      style: {
        fontSize: 'var(--text-sm)',
        color: 'var(--text-tertiary)'
      }
    }, t.sub)));
  })), /*#__PURE__*/React.createElement("div", {
    style: {
      marginTop: 30,
      textAlign: 'center'
    }
  }, /*#__PURE__*/React.createElement(Button, {
    variant: "primary",
    size: "lg",
    disabled: !type,
    onClick: () => setStep(1),
    iconRight: /*#__PURE__*/React.createElement(Icon, {
      name: "arrow-right",
      size: 20
    })
  }, "Continuer"))), step === 1 && /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement("h2", {
    style: {
      textAlign: 'center',
      marginBottom: 6
    }
  }, "Quelques infos rapides"), /*#__PURE__*/React.createElement("p", {
    style: {
      textAlign: 'center',
      color: 'var(--text-secondary)',
      marginBottom: 30
    }
  }, "Environ une minute. Aucun paiement requis pour voir les prix."), /*#__PURE__*/React.createElement(Card, {
    padding: "lg",
    style: {
      display: 'flex',
      flexDirection: 'column',
      gap: 18
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'grid',
      gridTemplateColumns: '1fr 1fr',
      gap: 16
    }
  }, /*#__PURE__*/React.createElement(Input, {
    label: "Nom complet",
    defaultValue: "Awa Kon\xE9"
  }), /*#__PURE__*/React.createElement(Input, {
    label: "Commune",
    placeholder: "Cocody, Abidjan",
    iconLeft: /*#__PURE__*/React.createElement(Icon, {
      name: "map-pin",
      size: 18
    })
  })), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'grid',
      gridTemplateColumns: '1fr 1fr',
      gap: 16
    }
  }, /*#__PURE__*/React.createElement(Select, {
    label: "Niveau de garantie",
    placeholder: "Choisir\u2026",
    options: ['Essentiel', 'Confort', 'Premium']
  }), /*#__PURE__*/React.createElement(Select, {
    label: "Date d\u2019effet",
    defaultValue: "asap",
    options: [{
      value: 'asap',
      label: 'Dès que possible'
    }, {
      value: 'later',
      label: 'Choisir une date'
    }]
  }))), /*#__PURE__*/React.createElement("div", {
    style: {
      marginTop: 28,
      display: 'flex',
      justifyContent: 'center',
      gap: 12
    }
  }, /*#__PURE__*/React.createElement(Button, {
    variant: "secondary",
    size: "lg",
    onClick: () => setStep(0)
  }, "Retour"), /*#__PURE__*/React.createElement(Button, {
    variant: "primary",
    size: "lg",
    onClick: () => setStep(2),
    iconRight: /*#__PURE__*/React.createElement(Icon, {
      name: "arrow-right",
      size: 20
    })
  }, "Voir mes devis"))), step === 2 && /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement("h2", {
    style: {
      textAlign: 'center',
      marginBottom: 6
    }
  }, "3 devis, pr\xEAts \xE0 souscrire"), /*#__PURE__*/React.createElement("p", {
    style: {
      textAlign: 'center',
      color: 'var(--text-secondary)',
      marginBottom: 30
    }
  }, "S\xE9lectionn\xE9s parmi nos partenaires. Prix garantis 30 jours."), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      flexDirection: 'column',
      gap: 14
    }
  }, d.quotes.map((q, i) => /*#__PURE__*/React.createElement(Card, {
    key: i,
    padding: "lg",
    style: {
      display: 'flex',
      alignItems: 'center',
      gap: 20,
      borderColor: i === 0 ? 'var(--brand)' : 'var(--border-subtle)'
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      flex: 1
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      alignItems: 'center',
      gap: 10,
      marginBottom: 4
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      fontWeight: 'var(--weight-semibold)',
      fontSize: 'var(--text-body-lg)'
    }
  }, q.provider), q.tag && /*#__PURE__*/React.createElement(Badge, {
    tone: i === 0 ? 'brand' : 'neutral'
  }, q.tag)), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      gap: 16,
      flexWrap: 'wrap',
      color: 'var(--text-secondary)',
      fontSize: 'var(--text-sm)'
    }
  }, q.features.map((f, j) => /*#__PURE__*/React.createElement("span", {
    key: j,
    style: {
      display: 'inline-flex',
      alignItems: 'center',
      gap: 5
    }
  }, /*#__PURE__*/React.createElement(Icon, {
    name: "check",
    size: 14,
    color: "var(--success)"
  }), " ", f)))), /*#__PURE__*/React.createElement("div", {
    style: {
      textAlign: 'right'
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      fontFamily: 'var(--font-mono)',
      fontVariantNumeric: 'tabular-nums',
      fontSize: 28,
      fontWeight: 'var(--weight-bold)',
      letterSpacing: '-0.02em'
    }
  }, q.price, /*#__PURE__*/React.createElement("span", {
    style: {
      fontSize: 14,
      color: 'var(--text-tertiary)',
      fontWeight: 400
    }
  }, q.cycle)), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'inline-flex',
      alignItems: 'center',
      gap: 3,
      fontSize: 'var(--text-caption)',
      color: 'var(--text-tertiary)',
      marginBottom: 10
    }
  }, /*#__PURE__*/React.createElement(Icon, {
    name: "star",
    size: 13,
    color: "var(--amber-500)"
  }), " ", q.rating), /*#__PURE__*/React.createElement(Button, {
    variant: i === 0 ? 'primary' : 'secondary',
    size: "sm",
    style: {
      display: 'block'
    }
  }, "Choisir"))))), /*#__PURE__*/React.createElement("div", {
    style: {
      marginTop: 26,
      textAlign: 'center'
    }
  }, /*#__PURE__*/React.createElement(Button, {
    variant: "ghost",
    onClick: onClose
  }, "Retour \xE0 l\u2019accueil")))));
}
Object.assign(window, {
  QuoteFlow
});
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/tilki-app/QuoteFlow.jsx", error: String((e && e.message) || e) }); }

// ui_kits/tilki-app/SignIn.jsx
try { (() => {
// TILKI sign-in — split layout, brand panel + form.
const {
  Icon,
  Button,
  Input
} = window.TILKIDesignSystem_7dda08;
function SignIn({
  onSignIn
}) {
  return /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      height: '100%',
      background: 'var(--bg-surface)'
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      flex: 1,
      display: 'flex',
      alignItems: 'center',
      justifyContent: 'center',
      padding: 32
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      width: '100%',
      maxWidth: 360
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      alignItems: 'center',
      gap: 9,
      marginBottom: 40
    }
  }, /*#__PURE__*/React.createElement("img", {
    src: window.__resources && window.__resources.logoMark || "../../assets/logo-mark.png",
    alt: "",
    style: {
      height: 28
    }
  }), /*#__PURE__*/React.createElement("img", {
    src: window.__resources && window.__resources.logoWordmark || "../../assets/logo-wordmark.png",
    alt: "TILKI",
    style: {
      height: 20
    }
  })), /*#__PURE__*/React.createElement("h1", {
    style: {
      fontSize: 'var(--text-h2)',
      marginBottom: 8
    }
  }, "Bon retour"), /*#__PURE__*/React.createElement("p", {
    style: {
      color: 'var(--text-secondary)',
      marginBottom: 30
    }
  }, "Connectez-vous pour g\xE9rer vos garanties."), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      flexDirection: 'column',
      gap: 18
    }
  }, /*#__PURE__*/React.createElement(Input, {
    label: "E-mail",
    type: "email",
    defaultValue: "awa.kone@email.ci",
    iconLeft: /*#__PURE__*/React.createElement(Icon, {
      name: "mail",
      size: 18
    })
  }), /*#__PURE__*/React.createElement(Input, {
    label: "Mot de passe",
    type: "password",
    defaultValue: "passwords",
    iconLeft: /*#__PURE__*/React.createElement(Icon, {
      name: "lock",
      size: 18
    })
  }), /*#__PURE__*/React.createElement(Button, {
    variant: "primary",
    size: "lg",
    fullWidth: true,
    onClick: onSignIn,
    iconRight: /*#__PURE__*/React.createElement(Icon, {
      name: "arrow-right",
      size: 20
    })
  }, "Se connecter")), /*#__PURE__*/React.createElement("div", {
    style: {
      textAlign: 'center',
      marginTop: 22,
      fontSize: 'var(--text-sm)',
      color: 'var(--text-tertiary)'
    }
  }, "Nouveau chez TILKI ? ", /*#__PURE__*/React.createElement("a", {
    href: "#",
    onClick: e => {
      e.preventDefault();
      onSignIn();
    },
    style: {
      fontWeight: 'var(--weight-semibold)'
    }
  }, "Obtenir un devis")))), /*#__PURE__*/React.createElement("div", {
    style: {
      flex: 1,
      background: 'var(--brand)',
      color: '#fff',
      position: 'relative',
      overflow: 'hidden',
      display: 'flex',
      flexDirection: 'column',
      justifyContent: 'flex-end',
      padding: 48
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      position: 'absolute',
      top: -60,
      right: -60,
      width: 320,
      height: 320,
      borderRadius: '50%',
      background: 'rgba(255,255,255,.08)'
    }
  }), /*#__PURE__*/React.createElement("div", {
    style: {
      position: 'absolute',
      top: 80,
      right: 120,
      width: 180,
      height: 180,
      borderRadius: '50%',
      background: 'rgba(255,255,255,.06)'
    }
  }), /*#__PURE__*/React.createElement(Icon, {
    name: "umbrella",
    size: 64,
    color: "#fff",
    strokeWidth: 1.6,
    style: {
      marginBottom: 24,
      opacity: .95
    }
  }), /*#__PURE__*/React.createElement("h2", {
    style: {
      fontSize: 'var(--text-h1)',
      color: '#fff',
      letterSpacing: '-0.02em',
      maxWidth: 420
    }
  }, "L\u2019assurance enfin simple."), /*#__PURE__*/React.createElement("p", {
    style: {
      color: 'rgba(255,255,255,.78)',
      fontSize: 'var(--text-body-lg)',
      maxWidth: 380,
      marginTop: 14
    }
  }, "Tous vos contrats au m\xEAme endroit, des experts qui analysent vos risques, et des prix revus chaque ann\xE9e.")));
}
Object.assign(window, {
  SignIn
});
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/tilki-app/SignIn.jsx", error: String((e && e.message) || e) }); }

// ui_kits/tilki-app/data.js
try { (() => {
// Données fictives pour le UI kit de l'app TILKI — Côte d'Ivoire, FCFA.
window.TILKI_DATA = {
  user: {
    name: 'Awa Koné',
    email: 'awa.kone@email.ci'
  },
  advisor: {
    name: 'Koffi N’Guessan',
    role: 'Votre conseiller assurance',
    phone: '+225 27 20 25 25 25'
  },
  policies: [{
    id: 'home',
    icon: 'home',
    name: 'Assurance habitation',
    provider: 'NSIA Assurances',
    premium: '9 500 FCFA',
    cycle: '/mois',
    annual: '114 000 FCFA',
    renews: '14 mars 2026',
    status: 'active',
    ref: 'POL-2026-004417',
    cover: 'Habitation & biens'
  }, {
    id: 'car',
    icon: 'car-front',
    name: 'Assurance auto',
    provider: 'Atlantique Assurances',
    premium: '18 000 FCFA',
    cycle: '/mois',
    annual: '216 000 FCFA',
    renews: '02 août 2026',
    status: 'active',
    ref: 'POL-2025-118822',
    cover: 'Tous risques'
  }, {
    id: 'travel',
    icon: 'plane',
    name: 'Assurance voyage',
    provider: 'SUNU Assurances',
    premium: '6 000 FCFA',
    cycle: '/mois',
    annual: '72 000 FCFA',
    renews: '21 janv. 2026',
    status: 'renewal',
    ref: 'POL-2025-660014',
    cover: 'Monde entier, annuelle'
  }, {
    id: 'life',
    icon: 'heart-pulse',
    name: 'Assurance vie',
    provider: 'Saham Assurance',
    premium: '12 000 FCFA',
    cycle: '/mois',
    annual: '144 000 FCFA',
    renews: '09 nov. 2026',
    status: 'active',
    ref: 'POL-2024-009921',
    cover: 'Temporaire, 25 000 000 FCFA'
  }],
  quoteTypes: [{
    id: 'home',
    icon: 'home',
    label: 'Maison',
    sub: 'Habitation & biens'
  }, {
    id: 'car',
    icon: 'car-front',
    label: 'Auto',
    sub: 'Garantie tous risques'
  }, {
    id: 'travel',
    icon: 'plane',
    label: 'Voyage',
    sub: 'Séjour unique ou annuel'
  }, {
    id: 'life',
    icon: 'heart-pulse',
    label: 'Vie',
    sub: 'Temporaire & vie entière'
  }],
  quotes: [{
    provider: 'NSIA Assurances',
    price: '16 500 FCFA',
    cycle: '/mois',
    tag: 'Meilleur prix',
    rating: '4,9',
    features: ['Franchise 0 FCFA en option', 'Biens à neuf', 'Assistance 24h/24']
  }, {
    provider: 'Atlantique Assurances',
    price: '18 000 FCFA',
    cycle: '/mois',
    tag: '',
    rating: '4,7',
    features: ['Franchise 50 000 FCFA', 'Biens jusqu’à 8 M FCFA', 'Option dépannage']
  }, {
    provider: 'SUNU Assurances',
    price: '21 000 FCFA',
    cycle: '/mois',
    tag: 'Mieux noté',
    rating: '5,0',
    features: ['Franchise 0 FCFA', 'Dommages accidentels', 'Protection juridique incluse']
  }]
};
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/tilki-app/data.js", error: String((e && e.message) || e) }); }

__ds_ns.Icon = __ds_scope.Icon;

__ds_ns.Avatar = __ds_scope.Avatar;

__ds_ns.Badge = __ds_scope.Badge;

__ds_ns.Card = __ds_scope.Card;

__ds_ns.StatCard = __ds_scope.StatCard;

__ds_ns.Dialog = __ds_scope.Dialog;

__ds_ns.Tooltip = __ds_scope.Tooltip;

__ds_ns.Button = __ds_scope.Button;

__ds_ns.Checkbox = __ds_scope.Checkbox;

__ds_ns.Input = __ds_scope.Input;

__ds_ns.Select = __ds_scope.Select;

__ds_ns.Switch = __ds_scope.Switch;

__ds_ns.Tabs = __ds_scope.Tabs;

})();
