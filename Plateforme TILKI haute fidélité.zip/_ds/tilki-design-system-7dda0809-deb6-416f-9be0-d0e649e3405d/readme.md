# TILKI Design System

> L'assurance enfin simple. Le langage de design de TILKI — un courtier en assurance basé en **Côte d'Ivoire** qui réunit, pour chaque foyer et chaque entreprise, tous les contrats au même endroit, avec un conseiller qui les connaît.

TILKI est une plateforme de **courtage en assurance** installée à **Abidjan, Côte d'Ivoire**. La langue est le **français** et la devise le **franc CFA (FCFA / XOF)**. TILKI se positionne comme **expert de l'assurance** — des capacités techniques, statistiques et analytiques poussées (analyse des risques, comparaison de marché, révision tarifaire annuelle) — le tout présenté avec une clarté désarmante.

Le modèle de design de TILKI est **Apple** : structure minimaliste, espaces généreux, confiance tranquille, et une seule couleur d'accent décisive. Rien de décoratif n'a sa place s'il n'aide pas à la clarté. L'expertise analytique se montre dans la précision des chiffres et la sobriété — jamais dans le tape-à-l'œil. La marque existe pour rendre une catégorie historiquement anxiogène et jargonneuse simple et maîtrisée.

## Sources
- `uploads/2.png.png` — the only supplied brand asset: the TILKI primary logo (umbrella mark + wordmark) in brand blue on a light ground. Logo variants were extracted from it into `assets/`.
- No codebase, Figma file, or live product was provided. The product surfaces (UI kit) and content are an **original, brand-consistent interpretation** built to the Apple-minimal direction the user specified — not a recreation of an existing screen. Treat them as a starting proposal to refine against the real product.

---

## Content fundamentals
How TILKI writes. **TILKI's language is French** — all product copy, marketing, and assets are written in French.

- **Voice:** calm, plain-spoken, reassuring. We sound like a knowledgeable friend, never a call centre or a legal document. Confidence without hype.
- **Person:** address the customer with the polite **« vous »**; refer to the brand as **« nous » / « TILKI »**. (« Nous comparons des assureurs de confiance pour trouver votre meilleur prix. »)
- **Tone by moment:** warm and human in marketing and greetings (« Mara, vous êtes bien couverte. »), precise and factual on policy and money screens (« 1 008 € prélevés par an »), gentle and clear on errors (« Contrat introuvable. »).
- **Casing:** sentence case everywhere — headings, buttons, labels, nav. Title Case is avoided. ALL-CAPS is reserved only for tiny eyebrow/caption labels with wide tracking. French spacing conventions apply (espace insécable before « : ? ! », « » guillemets).
- **Length:** short. Headlines are a single human sentence. Body explains one idea. Buttons are 1–3 words, verb-first (« Obtenir un devis », « Prendre rendez-vous », « Voir mes devis »).
- **Numbers & money:** the currency is the **franc CFA (FCFA)**, written after the amount with a thin-space thousands separator and no decimals (« 9 500 FCFA », « 546 000 FCFA »); large covers may abbreviate millions (« 8 M FCFA »). Ratings and rates use a comma decimal (« 4,9 »). Money and policy references always use the mono tabular face so they align and read as data — a deliberate nod to TILKI's analytical rigour. Insurance jargon (franchise, bonus-malus) is defined inline via tooltips rather than assumed. Phone numbers use the Ivorian format (« +225 27 20 25 25 25 »); places are communes (Cocody, Plateau, Yopougon…), not postcodes.
- **Emoji:** never. The personality comes from typography, spacing, and the umbrella mark — not emoji or exclamation marks.
- **Sample copy:**
  - Hero: *« L’assurance enfin simple. »*
  - Sub: *« Tous vos contrats au même endroit, des experts qui analysent vos risques, et des prix revus chaque année. »*
  - Empty state: *« Aucun sinistre sur ce contrat. En cas de problème, vous déclarez un sinistre en quelques minutes. »*
  - Reassurance: *« Entièrement protégée — aucune lacune dans vos garanties. »*

---

## Visual foundations
Answers to the brand's visual questions. Tokens live in `tokens/`; specimen cards in `guidelines/cards/`.

- **Color:** one brand color — **TILKI blue `#0F47F5`** — used decisively for primary actions, the umbrella mark, active nav, and key accents. Everything else is a cool, Apple-grade neutral grey ramp (`#1D1D1F` ink, `#6E6E73` secondary, `#F5F5F7` page, `#FFFFFF` surfaces, `#D2D2D7` borders). Semantic colors (green/amber/red) appear only as small status signals, always paired with a very subtle tinted background. The palette is restrained on purpose — blue + grey + white is the whole story.
- **Type:** **Manrope** (substituting Apple's SF Pro — see Caveats) for everything, with **JetBrains Mono** for monetary figures and policy/reference numbers. Base body is **17px** (Apple convention). Display and headings are bold with tight negative tracking (`-0.022em`); body runs at a generous 1.5 line height. Eyebrows are 13px uppercase with wide tracking.
- **Spacing:** 4px base grid; layouts breathe. Page gutters are generous (32px+), cards use 24px padding, sections separate by 28–40px. Whitespace is the primary layout tool — we add space before we add lines or boxes.
- **Backgrounds:** flat and quiet. A near-white page (`#F5F5F7`) with white surfaces. **No gradients on content**, no photographic hero washes, no textures or patterns. The one expressive moment is a **solid brand-blue panel** (sign-in, premium card) occasionally carrying faint translucent circles — never a multi-stop gradient.
- **Cards:** white, large radius (`20px`), a 1px hairline border (`#E5E5EA`) plus a very soft, low-contrast shadow (`--shadow-card`). Interactive cards lift 2px on hover. Cards are the primary container.
- **Corner radii:** soft and continuous. Buttons are **full pills**; inputs `14px`; cards `20px`; modals `28px`; icon tiles `12–16px`.
- **Shadows:** soft, diffuse, low-opacity — depth without weight. Never hard or dark drop shadows. Elevation rises from `xs` hairline to `xl` for modals.
- **Borders:** hairline 1px, in the neutral ramp. Used to separate rather than to decorate.
- **Transparency & blur:** sparingly. Modal scrims use a translucent ink overlay with a light backdrop blur. Brand panels use low-opacity white shapes. No frosted-glass everywhere.
- **Animation:** calm and confident, never bouncy. Apple-style ease curves (`cubic-bezier(0.4,0,0.2,1)` standard, a soft ease-out for entrances). Durations 140–360ms. Modals fade + rise 8px; tab indicator slides; nothing springs or overshoots.
- **Hover states:** primary buttons darken (`--brand-hover`); secondary fills with `--bg-sunken`; ghost picks up `--brand-subtle`; cards lift. Subtle, fast (140ms).
- **Press states:** buttons scale to `0.97` — a gentle physical press, no color flash.
- **Focus:** a 4px soft brand-blue ring (`--shadow-focus`) plus a blue border. Always visible for accessibility.
- **Imagery vibe:** the system ships no photography. If photography is added it should be bright, natural, warm-neutral and unstaged (real homes, real people) — never cold stock or moody filters. The umbrella mark is the hero visual.

---

## Iconography
- **Set:** [Lucide](https://lucide.dev) — thin, rounded-cap line icons that match the Apple-minimal, friendly-but-precise feel. This is a **substitution** (no icon set was supplied); flagged in Caveats.
- **Delivery:** loaded from CDN (`unpkg.com/lucide`) and wrapped by the `Icon` component (`components/core/Icon.jsx`), which renders true inline SVG so icons inherit `currentColor` and any stroke width.
- **Style rules:** default stroke `2px`; drop to `1.6–1.9` for large display icons. Icons are monochrome, taking text or brand color. Common ids: `umbrella` (brand motif), `shield`, `home`, `car-front`, `plane`, `heart-pulse`, `file-text`, `bell`, `calendar`, `check-circle`, `arrow-right`, `chevron-left/right`.
- **No emoji, no unicode glyphs as icons, no multicolor or filled icon styles.** The umbrella from the logo is the brand's signature symbol and may stand alone as a mark/favicon/app icon.

---

## Foundations at a glance
Token files (all imported by root `styles.css`):
- `tokens/colors.css` — brand blue ramp, neutral ramp, semantic accents, and semantic aliases (`--brand`, `--text-primary`, `--bg-page`, `--border`, …).
- `tokens/typography.css` — font families, type scale, weights, line-heights, tracking.
- `tokens/spacing.css` — 4px space scale + layout widths.
- `tokens/radius.css` — corner radii incl. component defaults.
- `tokens/shadow.css` — elevation + focus ring.
- `tokens/motion.css` — ease curves + durations.
- `tokens/fonts.css` — Manrope + JetBrains Mono (Google Fonts).
- `tokens/base.css` — light reset + base element styles.

---

## Index / manifest
Root files:
- `styles.css` — **the single entry point consumers link.** `@import`s only.
- `tokens/` — see above.
- `assets/` — `logo-full.png`, `logo-full-white.png`, `logo-mark.png`, `logo-mark-white.png`, `logo-wordmark.png`.
- `guidelines/cards/` — foundation specimen cards (Colors, Type, Spacing, Brand).
- `components/` — reusable primitives (see below).
- `ui_kits/tilki-app/` — interactive customer-app recreation.
- `SKILL.md` — Agent-Skill manifest for downloadable use.

Components (`window.TILKIDesignSystem_*` namespace — run `check_design_system` for the exact suffix):
- `components/core/` — **Icon**
- `components/forms/` — **Button**, **Input**, **Select**, **Switch**, **Checkbox**
- `components/display/` — **Card**, **Badge**, **Avatar**, **StatCard**
- `components/feedback/` — **Dialog**, **Tooltip**
- `components/navigation/` — **Tabs**

UI kits:
- `ui_kits/tilki-app/` — sign in → dashboard → policy detail → quote flow.

---

## Caveats / substitutions
- **Typeface:** Apple's SF Pro is not webfont-licensable, so **Manrope** stands in (closest free geometric-humanist match to the rounded TILKI wordmark). Swap for licensed SF Pro in production.
- **Icons:** **Lucide** substitutes for an unsupplied icon set.
- **Product surfaces & copy** are an original brand-consistent proposal, not a recreation of a real TILKI screen (none was provided).
